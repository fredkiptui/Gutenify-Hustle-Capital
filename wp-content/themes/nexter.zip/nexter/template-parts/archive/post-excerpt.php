<?php if(nexter_excerpt(30)){ ?>
<div class="nxt-entry-content">
	<p><?php echo nexter_excerpt(30); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
</div>
<?php } ?>