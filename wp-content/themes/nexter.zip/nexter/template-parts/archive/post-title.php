<h3 class="archive-post-title" itemprop="headline">
	<a href="<?php echo esc_url(get_the_permalink()); ?>" rel="bookmark"><?php the_title(); ?></a>
</h3>