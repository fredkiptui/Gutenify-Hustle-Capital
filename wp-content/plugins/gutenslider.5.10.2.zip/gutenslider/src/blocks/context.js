import {
  createContext,
} from '@wordpress/element';

export const AutoSlidesContext = createContext( false );