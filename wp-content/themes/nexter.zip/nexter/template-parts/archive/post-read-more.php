<div class="post-read-more nxt-flex">
	<a href="<?php echo esc_url(get_the_permalink()); ?>" rel="bookmark" class="button"><?php echo esc_html__('Read More','nexter'); ?></a>
</div>