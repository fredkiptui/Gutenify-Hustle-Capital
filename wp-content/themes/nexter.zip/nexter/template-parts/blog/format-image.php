<div class="nxt-blog-image">	
	<?php the_post_thumbnail(get_the_ID(), 'full', array('title' => '')); ?>	
</div>