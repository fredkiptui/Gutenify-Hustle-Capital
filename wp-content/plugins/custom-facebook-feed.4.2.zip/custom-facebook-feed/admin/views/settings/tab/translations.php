<div v-if="selected === 'app-3'">
    <div class="sb-tab-box sb-license-box d-flex">
        <div class="tab-label"><h3>Localization</h3></div>
    </div>
    <div class="sb-tab-box sb-license-box d-flex">
        <div class="tab-label"><h3>Custom CSS</h3></div>
    </div>
</div>
<!-- todo: this is just demo content and will be replaced once I work on this -->